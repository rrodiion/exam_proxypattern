# Спільний інтерфейс для реального об'єкта та його замісника
class Subject
  def request
    raise NotImplementedError, "#{self.class} has not implemented method '#{__method__}'"
  end
end

# Реальний об'єкт
class RealSubject < Subject
  def request
    puts "RealSubject: Обробка запиту."
  end
end

# Замісник
class Proxy < Subject
  attr_accessor :real_subject

  def initialize(real_subject)
    @real_subject = real_subject
  end

  def request
    # Додаткова логіка, яка може бути виконана перед передачею запиту реальному об'єкту
    puts "Proxy: Перевірка доступу до реального об'єкту."

    # Передача запиту реальному об'єкту
    real_subject.request
  end
end

# Використання
real_subject = RealSubject.new
proxy = Proxy.new(real_subject)

# Клієнт взаємодіє з об'єктом через замісник
proxy.request

